import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { 
  Rocket, 
  Clock, 
  Target, 
  Users, 
  CheckCircle, 
  AlertCircle, 
  Heart,
  Plus,
  Sparkles,
  Zap,
  Star
} from "lucide-react";

const StyleGuide = () => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-pastel-lavender/30 to-pastel-pink/30 font-poppins">
      {/* Header */}
      <header className="bg-gradient-to-r from-primary to-secondary text-white p-6 rounded-b-3xl shadow-xl">
        <div className="max-w-6xl mx-auto">
          <h1 className="text-4xl font-bold mb-2 flex items-center gap-3">
            <Sparkles className="animate-bounce" />
            Fun & Interactive Style Guide
            <Zap className="animate-pulse" />
          </h1>
          <p className="text-lg opacity-90">Pastel colors, rounded corners, and playful interactions ✨</p>
        </div>
      </header>

      <div className="max-w-6xl mx-auto p-6 space-y-12">
        
        {/* Color Palette */}
        <section className="space-y-6">
          <h2 className="text-3xl font-bold text-foreground mb-6 flex items-center gap-2">
            <div className="w-8 h-8 bg-gradient-to-r from-primary to-secondary rounded-full"></div>
            Color Palette
          </h2>
          
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <Card className="p-6 bg-gradient-to-br from-primary to-primary/80 text-primary-foreground rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-105">
              <div className="text-center">
                <div className="text-lg font-semibold">Primary</div>
                <div className="text-sm opacity-90">Lavender Purple</div>
              </div>
            </Card>
            
            <Card className="p-6 bg-gradient-to-br from-secondary to-secondary/80 text-secondary-foreground rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-105">
              <div className="text-center">
                <div className="text-lg font-semibold">Secondary</div>
                <div className="text-sm opacity-90">Playful Pink</div>
              </div>
            </Card>
            
            <Card className="p-6 bg-gradient-to-br from-success to-success/80 text-success-foreground rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-105">
              <div className="text-center">
                <div className="text-lg font-semibold">Success</div>
                <div className="text-sm opacity-90">Mint Green</div>
              </div>
            </Card>
            
            <Card className="p-6 bg-gradient-to-br from-warning to-warning/80 text-warning-foreground rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-105">
              <div className="text-center">
                <div className="text-lg font-semibold">Warning</div>
                <div className="text-sm opacity-90">Soft Yellow</div>
              </div>
            </Card>
          </div>
        </section>

        {/* Typography */}
        <section className="space-y-6">
          <h2 className="text-3xl font-bold text-foreground mb-6">Typography</h2>
          
          <Card className="p-8 bg-gradient-to-br from-card to-pastel-lavender/20 rounded-2xl shadow-lg">
            <div className="space-y-4">
              <h1 className="text-4xl font-bold font-poppins text-primary">Poppins - Primary Font</h1>
              <h2 className="text-3xl font-semibold font-poppins text-secondary">Headings are Bold & Rounded</h2>
              <h3 className="text-2xl font-medium font-nunito text-success">Nunito - Secondary Font</h3>
              <p className="text-lg font-poppins text-muted-foreground">Body text is light & breathable, not heavy. Perfect for reading!</p>
              <p className="text-base font-nunito text-foreground">Nunito brings soft curves and an approachable feel to smaller labels and descriptions.</p>
            </div>
          </Card>
        </section>

        {/* Buttons Showcase */}
        <section className="space-y-6">
          <h2 className="text-3xl font-bold text-foreground mb-6">Interactive Buttons</h2>
          
          <Card className="p-8 bg-gradient-to-br from-card to-pastel-mint/20 rounded-2xl shadow-lg">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <Button variant="default" className="flex items-center gap-2">
                <Rocket className="w-4 h-4" />
                Primary
              </Button>
              
              <Button variant="secondary" className="flex items-center gap-2">
                <Heart className="w-4 h-4" />
                Secondary
              </Button>
              
              <Button variant="success" className="flex items-center gap-2">
                <CheckCircle className="w-4 h-4" />
                Success
              </Button>
              
              <Button variant="warning" className="flex items-center gap-2">
                <AlertCircle className="w-4 h-4" />
                Warning
              </Button>
              
              <Button variant="outline" className="flex items-center gap-2">
                <Target className="w-4 h-4" />
                Outline
              </Button>
              
              <Button variant="ghost" className="flex items-center gap-2">
                <Users className="w-4 h-4" />
                Ghost
              </Button>
              
              <Button variant="fun" className="flex items-center gap-2">
                <Sparkles className="w-4 h-4" />
                Fun Gradient
              </Button>
              
              <Button variant="pill" className="flex items-center gap-2">
                <Plus className="w-4 h-4" />
                Pill Style
              </Button>
            </div>
          </Card>
        </section>

        {/* Dashboard Demo */}
        <section className="space-y-6">
          <h2 className="text-3xl font-bold text-foreground mb-6">Dashboard Preview</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* Project Card */}
            <Card className="p-6 bg-gradient-to-br from-pastel-lavender to-white rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-105 cursor-pointer">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-12 h-12 bg-gradient-to-r from-primary to-secondary rounded-full flex items-center justify-center">
                  <Rocket className="w-6 h-6 text-white animate-bounce" />
                </div>
                <div>
                  <h3 className="font-semibold text-lg">Launch Project</h3>
                  <p className="text-sm text-muted-foreground">Ready to deploy</p>
                </div>
              </div>
              <Progress value={85} className="mb-4" />
              <div className="flex justify-between items-center">
                <Badge className="bg-success/20 text-success border-success/30">85% Complete</Badge>
                <Button size="sm" variant="pill">View</Button>
              </div>
            </Card>

            {/* Deadline Card */}
            <Card className="p-6 bg-gradient-to-br from-pastel-yellow to-white rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-105 cursor-pointer">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-12 h-12 bg-gradient-to-r from-warning to-warning/80 rounded-full flex items-center justify-center">
                  <Clock className="w-6 h-6 text-warning-foreground animate-pulse" />
                </div>
                <div>
                  <h3 className="font-semibold text-lg">Deadline Soon</h3>
                  <p className="text-sm text-muted-foreground">Due in 2 days</p>
                </div>
              </div>
              <Progress value={60} className="mb-4" />
              <div className="flex justify-between items-center">
                <Badge className="bg-warning/20 text-warning border-warning/30">In Progress</Badge>
                <Button size="sm" variant="warning">Urgent</Button>
              </div>
            </Card>

            {/* Team Card */}
            <Card className="p-6 bg-gradient-to-br from-pastel-mint to-white rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-105 cursor-pointer">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-12 h-12 bg-gradient-to-r from-success to-success/80 rounded-full flex items-center justify-center">
                  <Users className="w-6 h-6 text-success-foreground animate-float" />
                </div>
                <div>
                  <h3 className="font-semibold text-lg">Team Project</h3>
                  <p className="text-sm text-muted-foreground">5 members active</p>
                </div>
              </div>
              <Progress value={100} className="mb-4" />
              <div className="flex justify-between items-center">
                <Badge className="bg-success/20 text-success border-success/30">Complete ✨</Badge>
                <Button size="sm" variant="success">Celebrate</Button>
              </div>
            </Card>
          </div>
        </section>

        {/* Form Elements */}
        <section className="space-y-6">
          <h2 className="text-3xl font-bold text-foreground mb-6">Form Elements</h2>
          
          <Card className="p-8 bg-gradient-to-br from-card to-pastel-pink/20 rounded-2xl shadow-lg">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-4">
                <div>
                  <Label htmlFor="task-name" className="text-base font-medium">Task Name</Label>
                  <Input 
                    id="task-name" 
                    placeholder="Enter a fun task name..." 
                    className="mt-2 rounded-xl border-2 focus:border-primary transition-colors" 
                  />
                </div>
                
                <div>
                  <Label htmlFor="description" className="text-base font-medium">Description</Label>
                  <Input 
                    id="description" 
                    placeholder="What makes this task awesome?" 
                    className="mt-2 rounded-xl border-2 focus:border-secondary transition-colors" 
                  />
                </div>
              </div>
              
              <div className="space-y-4">
                <div>
                  <Label className="text-base font-medium">Priority Level</Label>
                  <div className="flex gap-2 mt-2">
                    <Button variant="pill" size="sm" className="bg-success/20 text-success">
                      Low 🌱
                    </Button>
                    <Button variant="pill" size="sm" className="bg-warning/20 text-warning">
                      Medium ⚡
                    </Button>
                    <Button variant="pill" size="sm" className="bg-destructive/20 text-destructive">
                      High 🔥
                    </Button>
                  </div>
                </div>
                
                <Button variant="fun" className="w-full" size="lg">
                  <Plus className="w-5 h-5 mr-2" />
                  Create Awesome Task
                </Button>
              </div>
            </div>
          </Card>
        </section>

        {/* Kanban Preview */}
        <section className="space-y-6">
          <h2 className="text-3xl font-bold text-foreground mb-6">Kanban Board Style</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* To-Do Column */}
            <div className="bg-gradient-to-b from-pastel-lavender to-pastel-lavender/50 rounded-2xl p-4 shadow-lg">
              <div className="flex items-center gap-2 mb-4">
                <div className="text-lg font-semibold">To-Do</div>
                <div className="text-2xl">🐣</div>
              </div>
              
              <Card className="p-4 mb-3 bg-white rounded-xl shadow-sm hover:shadow-md transition-shadow cursor-pointer">
                <div className="flex items-center gap-2 mb-2">
                  <Target className="w-4 h-4 text-primary" />
                  <span className="font-medium">Design mockups</span>
                </div>
                <p className="text-sm text-muted-foreground">Create beautiful designs</p>
              </Card>
              
              <Card className="p-4 bg-white rounded-xl shadow-sm hover:shadow-md transition-shadow cursor-pointer">
                <div className="flex items-center gap-2 mb-2">
                  <Star className="w-4 h-4 text-secondary" />
                  <span className="font-medium">User research</span>
                </div>
                <p className="text-sm text-muted-foreground">Understand user needs</p>
              </Card>
            </div>

            {/* In Progress Column */}
            <div className="bg-gradient-to-b from-pastel-mint to-pastel-mint/50 rounded-2xl p-4 shadow-lg">
              <div className="flex items-center gap-2 mb-4">
                <div className="text-lg font-semibold">In Progress</div>
                <div className="text-2xl">🚀</div>
              </div>
              
              <Card className="p-4 mb-3 bg-white rounded-xl shadow-sm hover:shadow-md transition-shadow cursor-pointer">
                <div className="flex items-center gap-2 mb-2">
                  <Zap className="w-4 h-4 text-warning" />
                  <span className="font-medium">Frontend development</span>
                </div>
                <p className="text-sm text-muted-foreground">Building the interface</p>
              </Card>
            </div>

            {/* Done Column */}
            <div className="bg-gradient-to-b from-pastel-pink to-pastel-pink/50 rounded-2xl p-4 shadow-lg">
              <div className="flex items-center gap-2 mb-4">
                <div className="text-lg font-semibold">Done</div>
                <div className="text-2xl">🎉</div>
              </div>
              
              <Card className="p-4 bg-white rounded-xl shadow-sm hover:shadow-md transition-shadow cursor-pointer">
                <div className="flex items-center gap-2 mb-2">
                  <CheckCircle className="w-4 h-4 text-success" />
                  <span className="font-medium">Project setup</span>
                </div>
                <p className="text-sm text-muted-foreground">Repository initialized</p>
              </Card>
            </div>
          </div>
        </section>

        {/* Floating Action Button */}
        <div className="fixed bottom-8 right-8">
          <Button 
            variant="fun" 
            size="lg" 
            className="rounded-full w-14 h-14 shadow-2xl animate-bounce hover:animate-none"
          >
            <Plus className="w-6 h-6" />
          </Button>
        </div>
      </div>
    </div>
  );
};

export default StyleGuide;