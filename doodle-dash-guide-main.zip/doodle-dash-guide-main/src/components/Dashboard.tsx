import { useState } from "react";
import { Plus, Clock, TrendingUp, Users, CheckCircle } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import TopBar from "./layout/TopBar";
import Sidebar from "./layout/Sidebar";
import TaskCreationModal from "./TaskCreationModal";
import KanbanBoard from "./KanbanBoard";
import TeamManagement from "./TeamManagement";

const Dashboard = () => {
  const [activeView, setActiveView] = useState("dashboard");
  const [isTaskModalOpen, setIsTaskModalOpen] = useState(false);

  const projects = [
    {
      id: "1",
      title: "Website Redesign",
      progress: 75,
      deadline: "Dec 30, 2024",
      status: "on-track",
      tasks: 12,
      completedTasks: 9
    },
    {
      id: "2",
      title: "Mobile App Development",
      progress: 45,
      deadline: "Jan 15, 2025",
      status: "behind",
      tasks: 18,
      completedTasks: 8
    },
    {
      id: "3",
      title: "API Integration",
      progress: 90,
      deadline: "Dec 25, 2024",
      status: "ahead",
      tasks: 8,
      completedTasks: 7
    }
  ];

  const upcomingDeadlines = [
    { task: "User testing session", date: "Dec 24", priority: "high", project: "Website Redesign" },
    { task: "Database migration", date: "Dec 26", priority: "medium", project: "API Integration" },
    { task: "Design review", date: "Dec 28", priority: "low", project: "Mobile App" },
    { task: "Final deployment", date: "Dec 30", priority: "high", project: "Website Redesign" }
  ];

  const stats = [
    { label: "Active Projects", value: "3", icon: TrendingUp, color: "text-primary" },
    { label: "Team Members", value: "6", icon: Users, color: "text-secondary" },
    { label: "Completed Tasks", value: "24", icon: CheckCircle, color: "text-success" },
    { label: "Pending Tasks", value: "14", icon: Clock, color: "text-warning" }
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case "on-track": return "bg-primary";
      case "ahead": return "bg-success";
      case "behind": return "bg-destructive";
      default: return "bg-muted";
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "high": return "bg-destructive text-destructive-foreground border-destructive";
      case "medium": return "bg-warning text-warning-foreground border-warning";
      case "low": return "bg-success text-success-foreground border-success";
      default: return "bg-muted text-muted-foreground border-muted";
    }
  };

  const renderContent = () => {
    switch (activeView) {
      case "projects":
        return <KanbanBoard />;
      case "teams":
        return <TeamManagement />;
      case "settings":
        return (
          <div className="text-center py-20">
            <h2 className="text-2xl font-bold text-muted-foreground">Settings Coming Soon</h2>
            <p className="text-muted-foreground mt-2">Configure your workspace preferences here</p>
          </div>
        );
      default:
        return (
          <div className="space-y-8">
            {/* Stats Cards */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              {stats.map((stat, index) => {
                const Icon = stat.icon;
                return (
                  <Card key={index} className="bg-gradient-to-br from-card to-pastel-lavender/20 rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-105 border-0">
                    <CardContent className="p-6">
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="text-sm text-muted-foreground font-medium">{stat.label}</p>
                          <p className="text-3xl font-bold text-foreground mt-1">{stat.value}</p>
                        </div>
                        <Icon className={`w-8 h-8 ${stat.color}`} />
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              {/* Projects Section */}
              <div className="lg:col-span-2 space-y-6">
                <div className="flex items-center justify-between">
                  <h2 className="text-2xl font-bold font-poppins text-foreground">Active Projects</h2>
                  <Button variant="pill" size="sm">View All</Button>
                </div>

                <div className="space-y-4">
                  {projects.map((project) => (
                    <Card key={project.id} className="bg-gradient-to-br from-card to-white rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-[1.02] border-0">
                      <CardContent className="p-6">
                        <div className="space-y-4">
                          <div className="flex items-center justify-between">
                            <h3 className="text-lg font-semibold text-foreground">{project.title}</h3>
                            <Badge className={`${getStatusColor(project.status)} text-white px-3 py-1 rounded-full text-xs`}>
                              {project.status.replace("-", " ")}
                            </Badge>
                          </div>

                          <Progress value={project.progress} className="h-2" />

                          <div className="flex items-center justify-between text-sm">
                            <div className="flex items-center gap-4">
                              <span className="text-muted-foreground">
                                {project.completedTasks}/{project.tasks} tasks
                              </span>
                              <div className="flex items-center gap-1 text-muted-foreground">
                                <Clock className="w-4 h-4" />
                                <span>{project.deadline}</span>
                              </div>
                            </div>
                            <span className="font-semibold text-primary">{project.progress}%</span>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>

              {/* Upcoming Deadlines */}
              <div className="space-y-6">
                <h2 className="text-2xl font-bold font-poppins text-foreground">Upcoming Deadlines</h2>
                
                <div className="space-y-3">
                  {upcomingDeadlines.map((deadline, index) => (
                    <Card key={index} className="bg-gradient-to-br from-card to-pastel-mint/20 rounded-xl shadow-sm hover:shadow-md transition-all duration-300 border-0">
                      <CardContent className="p-4">
                        <div className="space-y-2">
                          <div className="flex items-center justify-between">
                            <h4 className="font-medium text-foreground text-sm">{deadline.task}</h4>
                            <Badge className={`${getPriorityColor(deadline.priority)} text-xs px-2 py-1 rounded-full`}>
                              {deadline.priority}
                            </Badge>
                          </div>
                          
                          <div className="flex items-center justify-between text-xs">
                            <span className="text-muted-foreground">{deadline.project}</span>
                            <div className="flex items-center gap-1 text-muted-foreground">
                              <Clock className="w-3 h-3" />
                              <span>{deadline.date}</span>
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>
            </div>
          </div>
        );
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-pastel-lavender/10 to-pastel-pink/10 font-poppins">
      <TopBar />
      
      <div className="flex">
        <Sidebar activeItem={activeView} onItemClick={setActiveView} />
        
        <main className="flex-1 p-8">
          <div className="max-w-7xl mx-auto">
            {renderContent()}
          </div>
        </main>
      </div>

      {/* Floating Action Button */}
      <div className="fixed bottom-8 right-8">
        <Button 
          variant="fun" 
          size="lg" 
          className="rounded-full w-14 h-14 shadow-2xl animate-float hover:animate-none"
          onClick={() => setIsTaskModalOpen(true)}
        >
          <Plus className="w-6 h-6" />
        </Button>
      </div>

      <TaskCreationModal 
        open={isTaskModalOpen} 
        onOpenChange={setIsTaskModalOpen} 
      />
    </div>
  );
};

export default Dashboard;