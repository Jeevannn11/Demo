import { useState } from "react";
import { Calendar, User, Flag, X } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";

interface TaskCreationModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

const TaskCreationModal = ({ open, onOpenChange }: TaskCreationModalProps) => {
  const [priority, setPriority] = useState<string>("");

  const assignees = [
    { id: "1", name: "Sarah Chen", avatar: "🧑‍💻" },
    { id: "2", name: "Mike Johnson", avatar: "👨‍💼" },
    { id: "3", name: "Emily Davis", avatar: "👩‍🎨" },
  ];

  const priorities = [
    { id: "low", label: "Low", color: "bg-success", emoji: "🌱" },
    { id: "medium", label: "Medium", color: "bg-warning", emoji: "⚡" },
    { id: "high", label: "High", color: "bg-destructive", emoji: "🔥" },
  ];

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px] bg-gradient-to-br from-card to-pastel-lavender/20 border-0 shadow-2xl rounded-2xl">
        <DialogHeader>
          <DialogTitle className="text-2xl font-bold font-poppins text-primary flex items-center gap-2">
            ✨ Create New Task
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6 pt-4">
          {/* Task Title */}
          <div className="space-y-2">
            <Label htmlFor="title" className="text-base font-medium text-foreground">
              Task Title
            </Label>
            <Input
              id="title"
              placeholder="What needs to be done?"
              className="rounded-xl border-2 focus:border-primary transition-colors text-base"
            />
          </div>

          {/* Description */}
          <div className="space-y-2">
            <Label htmlFor="description" className="text-base font-medium text-foreground">
              Description
            </Label>
            <Textarea
              id="description"
              placeholder="Add some details about this task..."
              className="rounded-xl border-2 focus:border-secondary transition-colors min-h-[100px] resize-none"
            />
          </div>

          {/* Assignee */}
          <div className="space-y-2">
            <Label className="text-base font-medium text-foreground">Assignee</Label>
            <Select>
              <SelectTrigger className="rounded-xl border-2 focus:border-primary">
                <SelectValue placeholder="Choose team member" />
              </SelectTrigger>
              <SelectContent className="rounded-xl">
                {assignees.map((assignee) => (
                  <SelectItem key={assignee.id} value={assignee.id} className="rounded-lg">
                    <div className="flex items-center gap-3">
                      <span className="text-lg">{assignee.avatar}</span>
                      <span>{assignee.name}</span>
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Deadline */}
          <div className="space-y-2">
            <Label className="text-base font-medium text-foreground">Deadline</Label>
            <Button 
              variant="outline" 
              className="w-full justify-start rounded-xl border-2 hover:border-primary transition-colors"
            >
              <Calendar className="w-4 h-4 mr-2" />
              Pick a date
            </Button>
          </div>

          {/* Priority */}
          <div className="space-y-3">
            <Label className="text-base font-medium text-foreground">Priority</Label>
            <div className="flex gap-3">
              {priorities.map((priorityOption) => (
                <Button
                  key={priorityOption.id}
                  variant={priority === priorityOption.id ? "default" : "outline"}
                  onClick={() => setPriority(priorityOption.id)}
                  className={`
                    flex-1 rounded-xl transition-all duration-300 hover:scale-105
                    ${priority === priorityOption.id 
                      ? priorityOption.color + " text-white shadow-lg" 
                      : "border-2 hover:border-primary"
                    }
                  `}
                >
                  <span className="mr-2">{priorityOption.emoji}</span>
                  {priorityOption.label}
                </Button>
              ))}
            </div>
          </div>

          {/* Actions */}
          <div className="flex gap-3 pt-4">
            <Button
              variant="outline"
              onClick={() => onOpenChange(false)}
              className="flex-1 rounded-xl border-2 hover:border-muted-foreground transition-colors"
            >
              Cancel
            </Button>
            <Button
              variant="fun"
              className="flex-1 rounded-xl shadow-lg"
            >
              Create Task ✨
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default TaskCreationModal;