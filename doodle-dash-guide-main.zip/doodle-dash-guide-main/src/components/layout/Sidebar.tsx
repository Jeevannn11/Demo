import { Home, FolderOpen, Users, Settings, Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

interface SidebarProps {
  activeItem?: string;
  onItemClick?: (item: string) => void;
}

const Sidebar = ({ activeItem = "dashboard", onItemClick }: SidebarProps) => {
  const menuItems = [
    { id: "dashboard", label: "Dashboard", icon: Home },
    { id: "projects", label: "Projects", icon: FolderOpen },
    { id: "teams", label: "Teams", icon: Users },
    { id: "settings", label: "Settings", icon: Settings },
  ];

  return (
    <aside className="w-64 bg-card border-r border-border shadow-sm h-full">
      <div className="p-6">
        <div className="space-y-2">
          {menuItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeItem === item.id;
            
            return (
              <Button
                key={item.id}
                variant={isActive ? "default" : "ghost"}
                className={cn(
                  "w-full justify-start gap-3 rounded-xl transition-all duration-300",
                  isActive 
                    ? "bg-gradient-to-r from-primary to-secondary text-white shadow-lg" 
                    : "hover:bg-pastel-lavender hover:scale-105"
                )}
                onClick={() => onItemClick?.(item.id)}
              >
                <Icon className="w-5 h-5" />
                <span className="font-medium">{item.label}</span>
                {isActive && <Sparkles className="w-4 h-4 ml-auto animate-pulse" />}
              </Button>
            );
          })}
        </div>
      </div>
    </aside>
  );
};

export default Sidebar;