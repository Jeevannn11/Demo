import { Clock, User, CircleDot, Rocket, PartyPopper } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";

const KanbanBoard = () => {
  const columns = [
    {
      id: "todo",
      title: "To-Do",
      icon: CircleDot,
      bgColor: "bg-gradient-to-b from-pastel-lavender to-pastel-lavender/50",
      tasks: [
        {
          id: "1",
          title: "Design system update",
          assignee: "Tanmay Kumar",
          deadline: "Dec 25",
          priority: "high"
        },
        {
          id: "2",
          title: "User research interviews",
          assignee: "Stuti Mishra",
          deadline: "Dec 28",
          priority: "medium"
        }
      ]
    },
    {
      id: "progress",
      title: "In Progress",
      icon: Rocket,
      bgColor: "bg-gradient-to-b from-pastel-mint to-pastel-mint/50",
      tasks: [
        {
          id: "3",
          title: "Frontend development",
          assignee: "Abhinash Parida",
          deadline: "Dec 30",
          priority: "high"
        }
      ]
    },
    {
      id: "done",
      title: "Done",
      icon: PartyPopper,
      bgColor: "bg-gradient-to-b from-pastel-pink to-pastel-pink/50",
      tasks: [
        {
          id: "4",
          title: "Project setup",
          assignee: "Dibya Ranjan Kumar",
          deadline: "Dec 20",
          priority: "low"
        },
        {
          id: "5",
          title: "Database schema design",
          assignee: "Abhisekh Dash",
          deadline: "Dec 22",
          priority: "medium"
        }
      ]
    }
  ];

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "high": return "bg-destructive";
      case "medium": return "bg-warning";
      case "low": return "bg-success";
      default: return "bg-muted";
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold font-poppins text-foreground">Kanban Board</h2>
        <Badge className="bg-gradient-to-r from-primary to-secondary text-white px-4 py-2 rounded-full">
          5 Active Tasks
        </Badge>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {columns.map((column) => (
          <div key={column.id} className={`${column.bgColor} rounded-2xl p-4 shadow-lg min-h-[400px]`}>
            {/* Column Header */}
            <div className="flex items-center gap-3 mb-6">
              <h3 className="text-lg font-semibold text-foreground">{column.title}</h3>
              <column.icon className="w-5 h-5 text-foreground" />
              <Badge variant="outline" className="ml-auto">
                {column.tasks.length}
              </Badge>
            </div>

            {/* Tasks */}
            <div className="space-y-3">
              {column.tasks.map((task) => (
                <Card 
                  key={task.id} 
                  className="bg-white rounded-xl shadow-sm hover:shadow-md transition-all duration-300 hover:scale-[1.02] cursor-pointer border-0"
                >
                  <CardContent className="p-4">
                    <div className="space-y-3">
                      {/* Task Title */}
                      <h4 className="font-semibold text-foreground text-sm leading-tight">
                        {task.title}
                      </h4>

                      {/* Task Meta */}
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <Avatar className="w-6 h-6">
                            <AvatarFallback className="text-xs font-semibold">
                              {task.assignee.split(' ').map(name => name[0]).join('')}
                            </AvatarFallback>
                          </Avatar>
                          <div className="flex flex-col gap-1">
                            <span className="text-xs font-medium text-foreground">{task.assignee}</span>
                            <div className="flex items-center gap-1 text-xs text-muted-foreground">
                              <Clock className="w-3 h-3" />
                              <span>{task.deadline}</span>
                            </div>
                          </div>
                        </div>

                        <div className={`w-3 h-3 rounded-full ${getPriorityColor(task.priority)}`}></div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}

              {/* Add Task Placeholder */}
              <Card className="bg-white/50 border-2 border-dashed border-muted-foreground/30 rounded-xl hover:border-primary transition-colors cursor-pointer">
                <CardContent className="p-4 text-center">
                  <div className="text-muted-foreground text-sm">
                    + Add new task
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default KanbanBoard;