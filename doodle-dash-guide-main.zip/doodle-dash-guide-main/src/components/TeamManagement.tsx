import { Search, Plus, Users } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";

const TeamManagement = () => {
  const teamMembers = [
    {
      id: "1",
      name: "Abhinash Parida",
      role: "Full Stack Developer",
      avatar: "🧑‍💻",
      taskCount: 8,
      status: "active"
    },
    {
      id: "2",
      name: "Dibya Ranjan Kumar",
      role: "Full Stack Developer",
      avatar: "👨‍💻",
      taskCount: 6,
      status: "active"
    },
    {
      id: "3",
      name: "Satweek Mohanty",
      role: "Full Stack Developer",
      avatar: "🧑‍💻",
      taskCount: 5,
      status: "busy"
    },
    {
      id: "4",
      name: "Abhisekh Dash",
      role: "Backend Developer",
      avatar: "👨‍💻",
      taskCount: 7,
      status: "active"
    },
    {
      id: "5",
      name: "Stuti Mishra",
      role: "Backend Developer",
      avatar: "👩‍💻",
      taskCount: 4,
      status: "available"
    },
    {
      id: "6",
      name: "Tanmay Kumar",
      role: "UI/UX cum Frontend",
      avatar: "👨‍🎨",
      taskCount: 9,
      status: "active"
    }
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case "active": return "bg-primary text-primary-foreground";
      case "busy": return "bg-warning text-warning-foreground";
      case "available": return "bg-success text-success-foreground";
      default: return "bg-muted text-muted-foreground";
    }
  };

  const getRoleColor = (role: string) => {
    if (role.includes("Manager")) return "text-secondary";
    if (role.includes("Developer")) return "text-primary";
    if (role.includes("Designer")) return "text-success";
    return "text-muted-foreground";
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold font-poppins text-foreground flex items-center gap-2">
            <Users className="w-7 h-7 text-primary" />
            Team Management
          </h2>
          <p className="text-muted-foreground mt-1">Manage your project team members</p>
        </div>
        
        <Button variant="fun" className="flex items-center gap-2">
          <Plus className="w-4 h-4" />
          Add Member
        </Button>
      </div>

      {/* Search Bar */}
      <div className="relative max-w-md">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
        <Input 
          placeholder="Search team members..." 
          className="pl-10 rounded-xl border-2 focus:border-primary transition-colors"
        />
      </div>

      {/* Team Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {teamMembers.map((member) => (
          <Card 
            key={member.id} 
            className="bg-gradient-to-br from-card to-pastel-lavender/20 rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-105 cursor-pointer border-0"
          >
            <CardContent className="p-6 text-center space-y-4">
              {/* Avatar */}
              <div className="w-16 h-16 bg-gradient-to-r from-primary/10 to-secondary/10 rounded-full flex items-center justify-center text-3xl mx-auto">
                {member.avatar}
              </div>

              {/* Member Info */}
              <div className="space-y-2">
                <h3 className="font-bold text-lg text-foreground">{member.name}</h3>
                <p className={`text-sm font-medium ${getRoleColor(member.role)}`}>
                  {member.role}
                </p>
              </div>

              {/* Status & Tasks */}
              <div className="flex items-center justify-between gap-2">
                <Badge className={`${getStatusColor(member.status)} px-3 py-1 rounded-full text-xs font-medium`}>
                  {member.status}
                </Badge>
                
                <Badge variant="outline" className="px-3 py-1 rounded-full text-xs">
                  {member.taskCount} tasks
                </Badge>
              </div>

              {/* Action Buttons */}
              <div className="flex gap-2 pt-2">
                <Button variant="outline" size="sm" className="flex-1 rounded-xl">
                  View Profile
                </Button>
                <Button variant="secondary" size="sm" className="flex-1 rounded-xl">
                  Assign Task
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}

        {/* Add Member Card */}
        <Card className="bg-gradient-to-br from-muted/20 to-muted/10 rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-105 cursor-pointer border-2 border-dashed border-muted-foreground/30 hover:border-primary">
          <CardContent className="p-6 text-center space-y-4 flex flex-col items-center justify-center h-full min-h-[280px]">
            <div className="w-16 h-16 bg-gradient-to-r from-primary/20 to-secondary/20 rounded-full flex items-center justify-center mx-auto">
              <Plus className="w-8 h-8 text-primary" />
            </div>
            
            <div className="space-y-2">
              <h3 className="font-semibold text-lg text-primary">Add New Member</h3>
              <p className="text-sm text-muted-foreground">Invite someone to join your team</p>
            </div>

            <Button variant="pill" className="mt-4">
              Invite Member
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default TeamManagement;